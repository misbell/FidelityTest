//
//  FidelityTestApp.swift
//  FidelityTest
//
//  Created by Michael Prenez-Isbell on 9/21/23.
//

import SwiftUI

@main
struct FidelityTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
